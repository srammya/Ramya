package controller;
 import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import io.prometheus.client.Counter;

@RestController
public class CounterController {
//    private final Counter requestCount;
//    static final Counter counter=Counter.
   
    	static final Counter counter= Counter.build()
    								.name("request_count")
    								.help("Number of hello requests.")
    								.register();
    

    @GetMapping(value = "/hello")
    public String hello() {
    	counter.inc();

        return "Hello!";
    }
}