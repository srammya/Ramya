package pages;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Sleeper;

import com.gargoylesoftware.htmlunit.javascript.host.Console;

import common.Page_BasePage;

public class Page_GoogleHomepage extends Page_BasePage {

	public void launchBrowser() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
		System.out.println("Launching chrome browser");
	}

	public void openSnapURL() {
		System.out.println("Snaponline website launched ");
		driver.get("https://wwwbeta.snapponline.co.uk/");
	}

	public void iopenSnapHomepage() {
		driver.get("https://wwwbeta.snapponline.co.uk/");
	}

	public void maximizemywindow() {
		driver.manage().window().maximize();
		System.out.println("browser  is maximized");
	}

	public void userone(String username) {
		assertEquals("Priya", username);

		System.out.println("User " + username + " Logged In Successfully");

	}

	public void usertwo() {

		System.out.println("User 2 Logged");
	}

	public void I_click_Google_Search_box() {

		System.out.println("Google Search box is clicked");
	}

	public void I_click_Im_feeling_Lucky_button() {

		System.out.println("feeling Lucky button is clicked");
	}

	public void checkSignIn() {

		if (driver.findElement(By.id("identifierId")).isDisplayed()) {
			System.out.println("SignIn Email Text is  box is displayed");

		} else {
			System.out.println("SignIn Email Text  box is NOT displayed");
		}
	}

	public void checkSearchBoxIsDisplayed() {
		if (driver.findElement(By.name("q")).isDisplayed()) {

			System.out.println("Search text box is displayed");
		} else {
			System.out.println("Search text box is NOT displayed");
		}
	}

	public void checkGoogleSearchButtonIsDisplayed() {
		if (driver.findElement(By.name("btnK")).isDisplayed()) {
			System.out.println("Google Search button is displayed");

		} else {
			System.out.println("Google Search button is NOT displayed");
			driver.close();
		}
	}

	public void checkImFeelingLuckyButtonIsDisplayed() {
		if (driver.findElement(By.name("btnI")).isDisplayed()) {
			System.out.println("I'm Feeling Lucky button is displayed");

		} else {
			System.out.println("I'm Feeling Lucky button is NOT displayed");
			driver.close();
		}
	}

	public void credentials() throws InterruptedException {

		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/app-root/app-header-home/div/div/div[3]/ul[2]/li[3]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"customerNumber\"]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"customerNumber\"]")).sendKeys("200006");
		driver.findElement(By.xpath("//*[@id=\"customerPassword\"]")).sendKeys("Test@1234");

	}

	public void login() throws InterruptedException {
		Thread.sleep(3000);
		driver.findElement(
				By.xpath("//*[@id=\"block-snapp-angular-nodes\"]/div/div/div/div/div/div/div/form/div[3]/button"))
				.click();
		System.out.println("Login is successful");
	}

	public void verify() throws InterruptedException {
		Thread.sleep(5000);

		driver.findElement(By.xpath(
				"/html/body/app-root/app-dashboard/div/div/div/div[2]/div/app-dashboard-delivery/div/div[1]/div/a/span"))
				.isDisplayed();

		Thread.sleep(5000);
		System.out.println("dashboard elements are displayed successfully");
		// driver.close();

	}

	public void notification_should_be_clicked1() throws InterruptedException {
		System.out.println("1 ok");
		driver.findElement(By.xpath(
				"/html/body/app-root/app-notify-centre/div/app-notify-centre-layout/div/div/div/div/div[2]/div/app-notification-item[1]/li/div"))
				.click();
		//
		System.out.println("My Notification is clicked");

		Thread.sleep(5000);
		WebElement myval = driver.findElement(By.xpath("//*[@id='heading621629185'][2]"));

		myval.click();
		Thread.sleep(5000);

		if (myval.isSelected()) {
			System.out.println("My on");
		} else {
			// System.out.println("Myoff");
		}
		myval.click();
//click del icon
		WebElement delicon = driver.findElement(By.xpath(
				"/html/body/app-root/app-notify-centre/div/app-notify-centre-layout/div/div/div/div/div[1]/div/div[2]/button[1]"));
		delicon.click();
		Thread.sleep(3000);
	}

	public void notification_should_be_clicked() throws InterruptedException {
		// notification tab
		Thread.sleep(5000);
		driver.findElement(By.xpath(
				"/html/body/app-root/app-dashboard/div/div/div/div[3]/div[2]/app-dashboard-notification-center/div/div[1]/div/a/span"))
				.click();
		//
		System.out.println("My Notification is clicked");

		Thread.sleep(5000);
		WebElement myval = driver.findElement(By.xpath("//*[@id='heading623944145'][2]"));

		myval.click();
		if (myval.isSelected()) {
			// System.out.println("My on");
		} else {
			// System.out.println("Myoff");
		}
		myval.click();
		// click del icon
		WebElement delicon = driver.findElement(By.xpath(
				"/html/body/app-root/app-notify-centre/div/app-notify-centre-layout/div/div/div/div/div[1]/div/div[2]/button[1]"));
		delicon.click();
		Thread.sleep(3000);
		WebElement opt = driver.findElement(By.xpath("//*[@id=\"due-book-modal\"]/div[3]/button[2]"));
		opt.click();

		Thread.sleep(5000);
		System.out.println("Notification msg deleted");
		// *[@id="heading621629172"]/a
		driver.close();
	}

	public void addclaimclick() {
		driver.findElement(By.xpath(
				"/html/body/app-root/app-delivery/div/div/app-delivery-all/section/div/div[2]/div[1]/app-delivery-detail[1]/div/div/div[3]/button"))
				.click();
		driver.findElement(By.xpath("/html/body/modal-container/div/div/div/div/div/div/div[1]/button/span")).click();

	}
}