package common;

import org.openqa.selenium.WebDriver;

public class Page_BasePage {



public static WebDriver driver;
}
