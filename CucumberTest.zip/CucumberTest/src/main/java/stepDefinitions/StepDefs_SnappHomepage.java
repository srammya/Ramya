package stepDefinitions;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Page_SnappHomepage;


public class StepDefs_SnappHomepage {
	
	Page_SnappHomepage pagesnapphomepage =new Page_SnappHomepage();
	
@Given("^I launch Chrome browser$")	
public void i_launch_Chrome_browser() throws Exception{
	pagesnapphomepage.launchBrowser();
	
}

@And("^maximize my window$")
public void maximize_my_window() throws Exception{
	pagesnapphomepage.maximizemywindow();
	
}
@When("^I open Snap Homepage$")
public void i_open_Snap_HomePage() throws Exception{
	pagesnapphomepage.openSnapURL();
}

@Given("^Login credentials$")
public void Login_credentials() throws Exception{
	pagesnapphomepage.credentials();
	
}

@Given("^I Login to the snap Online$")
public void I_Login_to_the_snap_Online() throws Exception{
	pagesnapphomepage.login();
	
}

@Then("^verify dashboard element are displayed$")
public void verify() throws Exception{
	pagesnapphomepage.verify();
}
@Then("^I verify that the page displays search text box$")
public void i_verify_that_the_page_displays_search_text_box() throws Exception{
	pagesnapphomepage.checkSearchBoxIsDisplayed();
}
@Then("^the page displays Google Search button$")
public void the_page_displays_Google_Search_button() throws Exception{
	pagesnapphomepage.checkGoogleSearchButtonIsDisplayed();
}
@Then("^the page displays Im Feeling Lucky button$")
public void the_page_displays_Im_Feeling_Lucky_button() throws Exception{
	pagesnapphomepage.checkImFeelingLuckyButtonIsDisplayed();
}



@Then("^I verify that the page displays signin text box$")
public void I_verify_that_the_page_displays_signin_text_box() throws Exception{
	pagesnapphomepage.checkSignIn();
}


@Given("^I am user one \"([^\"]*)\" and \"([^\"]*)\"$")
public void I_am_user_one(String username ,String Password) throws Exception{
	pagesnapphomepage.userone(username);
}

@Given("^I am user two$")
public void I_am_user_two() throws Exception{
	pagesnapphomepage.usertwo();
}

@Then("^I click Google Search box$")
public void I_click_Google_Search_box() throws Exception{
	pagesnapphomepage.I_click_Google_Search_box();
}
@Then("^I click Im feeling Lucky button$")
public void I_click_Im_feeling_Lucky_button() throws Exception{
	pagesnapphomepage.I_click_Im_feeling_Lucky_button();
}

@Then("^Notification should be clicked and deleted$")
public void notification_should_be_clicked() throws Exception{
	pagesnapphomepage.notification_should_be_clicked();;
	
}


@And("^AddClaim should be clicked$")
public void AddClaim_should_be_clicked() throws Exception{
	pagesnapphomepage.addclaimclick();
	
}



}
